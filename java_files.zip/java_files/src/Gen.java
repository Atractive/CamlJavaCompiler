import java.util.*;
public class Gen {
public static LinkedList<Instr> code =
LLE.add_elem(new Quote(new IntV(2)),
LLE.empty());
}
