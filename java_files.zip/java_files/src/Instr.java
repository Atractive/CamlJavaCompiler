abstract class Instr extends Object {

    void exec_instr(Config cf) {
	System.out.println("exec_instr " + this + "NOT IMPLEMENTED");
    }

}
