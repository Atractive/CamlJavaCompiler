abstract class StackElem extends Object {

}
